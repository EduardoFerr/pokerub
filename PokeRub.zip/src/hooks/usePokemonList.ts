/**
 * @file Hook customizado para buscar e gerenciar a lista de Pokémons.
 */
import { useState, useMemo } from 'react';
import { useQuery } from 'urql';
import { GET_POKEMON_LIST } from '../api/queries';
import { BasePokemon, GQLQueryResponse } from '../types/pokemon';

const PAGE_SIZE = 20;

/**
 * Retorna a lista de pokémons com paginação e busca local/remota.
 *
 * @param searchTerm Filtro opcional por nome
 * @returns Um objeto contendo a lista de pokémons, estado de carregamento, erros e função para carregar mais.
 */
export const usePokemonList = (searchTerm: string) => {
  const [offset, setOffset] = useState(0);

  const [{ data, fetching, error }, executeQuery] = useQuery<GQLQueryResponse<BasePokemon>>({
    query: GET_POKEMON_LIST,
    variables: { limit: PAGE_SIZE, offset },
  });

  // Otimização aplicada: 'pokemons' agora é memoizado e só será recriado quando 'data' mudar.
  const pokemons = useMemo(() => data?.pokemon_v2_pokemon ?? [], [data]);

  const filteredPokemons = useMemo(() => {
    if (!searchTerm) return pokemons;
    return pokemons.filter(p => p.name.toLowerCase().includes(searchTerm.toLowerCase()));
  }, [pokemons, searchTerm]);

  const fetchMore = () => {
    if (fetching || !data) return;
    setOffset(currentOffset => currentOffset + PAGE_SIZE);
  };

  const refresh = () => {
    setOffset(0);
    executeQuery({ requestPolicy: 'network-only' });
  }

  return {
    pokemons: filteredPokemons,
    loading: fetching,
    error,
    fetchMore,
    refresh,
  };
};
